# inventory/admin.py

from django.contrib import admin
from import_export.admin import ImportExportModelAdmin
from .models import Device, Owner, Room
from .resources import DeviceResource, OwnerResource, RoomResource

@admin.register(Device)
class DeviceAdmin(ImportExportModelAdmin):
    resource_class = DeviceResource
    list_display = ('name', 'inventory_number', 'get_owner', 'get_room')
    search_fields = ('name', 'inventory_number', 'owner__name', 'room__name')
    list_filter = ('room', 'owner')
    ordering = ('inventory_number',)

    def get_owner(self, obj):
        return obj.owner.name if obj.owner else "No Owner"
    get_owner.short_description = 'Device Owner'

    def get_room(self, obj):
        return obj.room.name if obj.room else "No Room"
    get_room.short_description = 'Room/Area'

@admin.register(Owner)
class OwnerAdmin(ImportExportModelAdmin):
    resource_class = OwnerResource
    list_display = ('name',)
    search_fields = ('name',)

@admin.register(Room)
class RoomAdmin(ImportExportModelAdmin):
    resource_class = RoomResource
    list_display = ('name',)
    search_fields = ('name',)
