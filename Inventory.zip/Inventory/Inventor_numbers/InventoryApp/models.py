# inventory/models.py

from django.db import models

class Owner(models.Model):
    name = models.CharField(max_length=255, unique=True)  # Enforce unique names

    class Meta:
        verbose_name = "Device Owner"
        verbose_name_plural = "Device Owners"

    def __str__(self):
        return self.name

class Room(models.Model):
    name = models.CharField(max_length=255, unique=True)  # Enforce unique names

    class Meta:
        verbose_name = "Room/Area"
        verbose_name_plural = "Rooms/Areas"

    def __str__(self):
        return self.name

class Device(models.Model):
    name = models.CharField("Device Name", max_length=255)
    inventory_number = models.CharField("Inventory Number", max_length=100, unique=True)
    owner = models.ForeignKey(
        Owner,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='devices',
        verbose_name="Device Owner"
    )
    room = models.ForeignKey(
        Room,
        on_delete=models.SET_NULL,
        null=True,
        blank=True,
        related_name='devices',
        verbose_name="Room/Area"
    )

    class Meta:
        verbose_name = "Device"
        verbose_name_plural = "Devices"
        ordering = ['inventory_number']

    def __str__(self):
        return f"{self.name} ({self.inventory_number})"


