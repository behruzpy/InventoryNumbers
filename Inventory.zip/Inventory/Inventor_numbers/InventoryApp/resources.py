# inventory/resources.py

from import_export import resources, fields
from import_export.widgets import ForeignKeyWidget
from .models import Device, Owner, Room
from import_export.admin import ImportExportModelAdmin


class OwnerResource(resources.ModelResource):
    class Meta:
        model = Owner
        fields = ('id', 'name',)
        import_id_fields = ('name',)  # Use 'name' to identify existing records
        skip_unchanged = True
        report_skipped = True

class RoomResource(resources.ModelResource):
    class Meta:
        model = Room
        fields = ('id', 'name',)
        import_id_fields = ('name',)  # Use 'name' to identify existing records
        skip_unchanged = True
        report_skipped = True

class DeviceResource(resources.ModelResource):
    owner = fields.Field(
        column_name='Device Owner',
        attribute='owner',
        widget=ForeignKeyWidget(Owner, 'name')  # Link via Owner's name
    )
    room = fields.Field(
        column_name='Room/Area',
        attribute='room',
        widget=ForeignKeyWidget(Room, 'name')  # Link via Room's name
    )

    class Meta:
        model = Device
        fields = ('id', 'name', 'inventory_number', 'owner', 'room',)
        import_id_fields = ('inventory_number',)  # Use 'inventory_number' to identify existing devices
        skip_unchanged = True
        report_skipped = True
